from django.apps import AppConfig


class ExtractFromDocumentsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'extract_from_documents'
